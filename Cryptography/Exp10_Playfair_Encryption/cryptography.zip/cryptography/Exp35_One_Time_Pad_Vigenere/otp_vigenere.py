import random
import string

def otp_vigenere_demo():
    print("--- One-Time Pad / Vigenère Cipher ---")
    
    plaintext = "CRYPTOGRAPHY".upper()
    print(f"Plaintext: {plaintext}")
    
    # Generate random key of the same length
    key_stream = [random.randint(0, 25) for _ in range(len(plaintext))]
    print(f"Random Key Stream: {key_stream}")
    
    # Encrypt: C[i] = (P[i] + K[i]) mod 26
    ciphertext = ""
    for i in range(len(plaintext)):
        p_val = ord(plaintext[i]) - 65
        c_val = (p_val + key_stream[i]) % 26
        ciphertext += chr(c_val + 65)
        
    print(f"Ciphertext: {ciphertext}")
    
    # Decrypt: P[i] = (C[i] - K[i]) mod 26
    decrypted = ""
    for i in range(len(ciphertext)):
        c_val = ord(ciphertext[i]) - 65
        p_val = (c_val - key_stream[i]) % 26
        decrypted += chr(p_val + 65)
        
    print(f"Decrypted: {decrypted}")
    
    if plaintext == decrypted:
        print("\nSuccess! Perfect secrecy achieved if key is truly random, never reused, and kept secret.")

if __name__ == "__main__":
    otp_vigenere_demo()
