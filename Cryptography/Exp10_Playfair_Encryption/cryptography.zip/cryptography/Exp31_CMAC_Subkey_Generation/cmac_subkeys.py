def left_shift(val, bits_len):
    return (val << 1) & ((1 << bits_len) - 1)

def generate_cmac_subkeys(block_bits, Rb, dummy_L):
    # K1
    msb = dummy_L >> (block_bits - 1)
    K1 = left_shift(dummy_L, block_bits)
    if msb == 1:
        K1 ^= Rb
        
    # K2
    msb_k1 = K1 >> (block_bits - 1)
    K2 = left_shift(K1, block_bits)
    if msb_k1 == 1:
        K2 ^= Rb
        
    return K1, K2

def cmac_subkey_demo():
    print("--- CMAC Subkey Generation Demonstration ---")
    
    print("\n1. 64-bit Block Size")
    Rb_64 = 0x1B
    print(f"Constant Rb for 64-bit: 0x{Rb_64:02X}")
    # Let L be E(K, 0^n). For demo, assume L has MSB=1
    L_64 = 0x8000000000000000
    K1_64, K2_64 = generate_cmac_subkeys(64, Rb_64, L_64)
    print(f"L  = 0x{L_64:016X}")
    print(f"K1 = 0x{K1_64:016X}")
    print(f"K2 = 0x{K2_64:016X}")
    
    print("\n2. 128-bit Block Size")
    Rb_128 = 0x87
    print(f"Constant Rb for 128-bit: 0x{Rb_128:02X}")
    L_128 = 0x80000000000000000000000000000000
    K1_128, K2_128 = generate_cmac_subkeys(128, Rb_128, L_128)
    print(f"L  = 0x{L_128:032X}")
    print(f"K1 = 0x{K1_128:032X}")
    print(f"K2 = 0x{K2_128:032X}")
    
    print("\nExplanation:")
    print("CMAC generates two subkeys (K1, K2) from the block cipher encryption of all zeros (L).")
    print("K1 is derived by left-shifting L by 1 bit. If the MSB of L was 1, we XOR the result")
    print("with a standard constant (Rb). K2 is derived from K1 in the exact same manner.")
    print("These subkeys are XORed into the final message block to handle padding cases securely.")

if __name__ == "__main__":
    cmac_subkey_demo()
