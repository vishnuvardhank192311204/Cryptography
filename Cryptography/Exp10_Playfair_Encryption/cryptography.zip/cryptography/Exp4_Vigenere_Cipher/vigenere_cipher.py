# Vigenere Cipher
plaintext = input("Enter the plaintext: ")
key = input("Enter the key: ")

print("\n--- Encryption ---")
print("Plaintext:", plaintext)
print("Key:", key)

# Clean the key to only have uppercase letters
clean_key = ""
for char in key.upper():
    if char >= 'A' and char <= 'Z':
        clean_key += char

ciphertext = ""
key_index = 0
for char in plaintext:
    if char >= 'A' and char <= 'Z':
        shift = ord(clean_key[key_index % len(clean_key)]) - 65
        new_char = chr(((ord(char) - 65 + shift) % 26) + 65)
        ciphertext += new_char
        key_index += 1
    elif char >= 'a' and char <= 'z':
        shift = ord(clean_key[key_index % len(clean_key)]) - 65
        new_char = chr(((ord(char) - 97 + shift) % 26) + 97)
        ciphertext += new_char
        key_index += 1
    else:
        ciphertext += char

print("Ciphertext:", ciphertext)

print("\n--- Decryption ---")
decrypted = ""
key_index = 0
for char in ciphertext:
    if char >= 'A' and char <= 'Z':
        shift = ord(clean_key[key_index % len(clean_key)]) - 65
        new_char = chr(((ord(char) - 65 - shift) % 26) + 65)
        decrypted += new_char
        key_index += 1
    elif char >= 'a' and char <= 'z':
        shift = ord(clean_key[key_index % len(clean_key)]) - 65
        new_char = chr(((ord(char) - 97 - shift) % 26) + 97)
        decrypted += new_char
        key_index += 1
    else:
        decrypted += char

print("Decrypted text:", decrypted)
