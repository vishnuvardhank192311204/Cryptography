# Experiment 4: Vigenere Cipher

## Aim
To implement the Vigenere Cipher.

## Algorithm
1. Match the key repeatedly with the length of the plaintext.
2. For encryption, shift each plaintext character by the corresponding key character's alphabetical position (A=0, B=1, etc.).
3. For decryption, shift backwards by the same amount.

## Program
The program is implemented in `vigenere_cipher.py`.

## Sample Input
Plaintext: WE ARE DISCOVERED SAVE YOURSELF
Key: DECEPTIVE

## Sample Output
Ciphertext: ZICVTWQNGRZGVTWAVZCQSMNGZ
Decrypted text: WEAREDISCOVEREDSAVEYOURSELF

## Result
The Vigenere cipher was successfully implemented and executed.
