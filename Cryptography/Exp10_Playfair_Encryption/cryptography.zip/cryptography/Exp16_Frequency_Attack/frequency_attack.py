import string
from collections import Counter

# Standard English letter frequencies (approximate percentages)
ENGLISH_FREQ = {
    'E': 12.7, 'T': 9.1, 'A': 8.2, 'O': 7.5, 'I': 7.0, 'N': 6.7, 'S': 6.3, 'H': 6.1, 'R': 6.0,
    'D': 4.3, 'L': 4.0, 'C': 2.8, 'U': 2.8, 'M': 2.4, 'W': 2.4, 'F': 2.2, 'G': 2.0, 'Y': 2.0,
    'P': 1.9, 'B': 1.5, 'V': 0.9, 'K': 0.8, 'J': 0.15, 'X': 0.15, 'Q': 0.10, 'Z': 0.07
}
FREQ_ORDER = sorted(ENGLISH_FREQ.keys(), key=lambda x: ENGLISH_FREQ[x], reverse=True)

def score_text(text):
    score = 0
    counts = Counter([c for c in text if c in string.ascii_uppercase])
    total = sum(counts.values())
    if total == 0: return 0
    
    for char, count in counts.items():
        freq = (count / total) * 100
        # Calculate difference from expected
        if char in ENGLISH_FREQ:
            score -= abs(freq - ENGLISH_FREQ[char])
        else:
            score -= freq
    return score

def frequency_attack(ciphertext, top_n=10):
    print("--- Frequency Attack ---")
    ciphertext = ciphertext.upper()
    ct_counts = Counter([c for c in ciphertext if c in string.ascii_uppercase])
    
    if not ct_counts:
        print("No alphabet characters to analyze.")
        return
        
    ct_order = [x[0] for x in ct_counts.most_common()]
    
    # We will generate candidates by shifting the frequency mapping slightly
    candidates = []
    
    # Simplified approach: map the most frequent CT letter to E, T, A, O, etc.
    # We'll just generate shifts as candidates for demonstration, since full substitution tree is huge
    # But for a true monoalphabetic attack without knowing it's a shift, we map frequencies directly
    
    # Direct mapping mapping (most frequent CT -> most frequent English)
    direct_map = {}
    for i in range(min(len(ct_order), len(FREQ_ORDER))):
        direct_map[ct_order[i]] = FREQ_ORDER[i]
        
    # Generate one direct candidate
    pt_direct = ""
    for c in ciphertext:
        pt_direct += direct_map.get(c, c)
        
    candidates.append((score_text(pt_direct), pt_direct, "Direct Frequency Map"))
    
    # Generate shift candidates (just in case it's a simple shift disguised as monoalphabetic)
    for shift in range(1, 26):
        pt = ""
        for c in ciphertext:
            if c in string.ascii_uppercase:
                pt += chr(((ord(c) - 65 - shift) % 26) + 65)
            else:
                pt += c
        candidates.append((score_text(pt), pt, f"Shift {shift}"))
        
    candidates.sort(reverse=True, key=lambda x: x[0])
    
    print(f"\nDisplaying top {top_n} candidates:\n")
    for i in range(min(top_n, len(candidates))):
        print(f"Rank {i+1} (Score: {candidates[i][0]:.2f} | {candidates[i][2]})\nCandidate: {candidates[i][1]}\n")

if __name__ == "__main__":
    ct = input("Enter ciphertext: ")
    n_str = input("How many candidates to display (default 10): ")
    n = int(n_str) if n_str.isdigit() else 10
    frequency_attack(ct, n)
