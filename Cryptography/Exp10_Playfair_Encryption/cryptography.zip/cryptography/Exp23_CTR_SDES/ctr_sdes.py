# S-DES Implementation and CTR Mode
import sys

# P10, P8, IP, EP, P4, IP_inv tables
P10 = [3, 5, 2, 7, 4, 10, 1, 9, 8, 6]
P8 = [6, 3, 7, 4, 8, 5, 10, 9]
IP = [2, 6, 3, 1, 4, 8, 5, 7]
EP = [4, 1, 2, 3, 2, 3, 4, 1]
P4 = [2, 4, 3, 1]
IP_inv = [4, 1, 3, 5, 7, 2, 8, 6]

S0 = [[1, 0, 3, 2], [3, 2, 1, 0], [0, 2, 1, 3], [3, 1, 3, 2]]
S1 = [[0, 1, 2, 3], [2, 0, 1, 3], [3, 0, 1, 0], [2, 1, 0, 3]]

def permute(bits, table): return [bits[i-1] for i in table]
def left_shift(bits, n): return bits[n:] + bits[:n]

def key_generation(key):
    k = permute(key, P10)
    L, R = k[:5], k[5:]
    L, R = left_shift(L, 1), left_shift(R, 1)
    k1 = permute(L + R, P8)
    L, R = left_shift(L, 2), left_shift(R, 2)
    k2 = permute(L + R, P8)
    return k1, k2

def sbox(bits, sbox_matrix):
    row = (bits[0] << 1) | bits[3]
    col = (bits[1] << 1) | bits[2]
    val = sbox_matrix[row][col]
    return [(val >> 1) & 1, val & 1]

def f_k(bits, key):
    L, R = bits[:4], bits[4:]
    R_exp = permute(R, EP)
    xor_res = [r ^ k for r, k in zip(R_exp, key)]
    s0_res = sbox(xor_res[:4], S0)
    s1_res = sbox(xor_res[4:], S1)
    p4_res = permute(s0_res + s1_res, P4)
    new_L = [l ^ p for l, p in zip(L, p4_res)]
    return new_L + R

def sdes_encrypt(pt, k1, k2):
    bits = permute(pt, IP)
    bits = f_k(bits, k1)
    bits = bits[4:] + bits[:4]
    bits = f_k(bits, k2)
    return permute(bits, IP_inv)

def to_bits(binary_str): return [int(c) for c in binary_str]
def to_str(bits): return "".join(str(b) for b in bits)
def xor_lists(l1, l2): return [a ^ b for a, b in zip(l1, l2)]

def increment_counter(counter_bits):
    val = int(to_str(counter_bits), 2)
    val = (val + 1) % 256
    bin_str = format(val, '08b')
    return to_bits(bin_str)

def main():
    print("--- CTR S-DES Demonstration ---")
    ctr_str = "00000000"
    pt_str = "000000010000001000000100"
    key_str = "0111111101"
    expected_ct_str = "001110000100111100110010"
    
    key = to_bits(key_str)
    ctr = to_bits(ctr_str)
    
    k1, k2 = key_generation(key)
    
    pt_blocks = [to_bits(pt_str[i:i+8]) for i in range(0, len(pt_str), 8)]
    
    print(f"Initial CTR: {ctr_str}")
    print(f"Plaintext: {pt_str[:8]} {pt_str[8:16]} {pt_str[16:]}")
    print(f"Key: {key_str}\\n")
    
    # CTR Encrypt
    ct_blocks = []
    current_ctr = ctr
    for pt in pt_blocks:
        enc_ctr = sdes_encrypt(current_ctr, k1, k2)
        ct = xor_lists(pt, enc_ctr)
        ct_blocks.append(ct)
        current_ctr = increment_counter(current_ctr)
        
    final_ct_str = "".join(to_str(cb) for cb in ct_blocks)
    
    print(f"Encrypted Ciphertext: {final_ct_str[:8]} {final_ct_str[8:16]} {final_ct_str[16:]}")
    print(f"Expected Ciphertext : {expected_ct_str[:8]} {expected_ct_str[8:16]} {expected_ct_str[16:]}")
    
    if final_ct_str == expected_ct_str:
        print("Encryption: PASS")
    else:
        print("Encryption: FAIL")
        
    # CTR Decrypt (Same as encrypt)
    dec_blocks = []
    current_ctr = ctr
    for ct in ct_blocks:
        enc_ctr = sdes_encrypt(current_ctr, k1, k2)
        pt = xor_lists(ct, enc_ctr)
        dec_blocks.append(pt)
        current_ctr = increment_counter(current_ctr)
        
    final_pt_str = "".join(to_str(db) for db in dec_blocks)
    if final_pt_str == pt_str:
        print("\\nDecryption: PASS")
    else:
        print("\\nDecryption: FAIL")

if __name__ == "__main__":
    main()
