# Frequency Attack on Caesar Cipher

# Dictionary of standard English letter frequencies
english_freq = {
    'A': 8.167, 'B': 1.492, 'C': 2.782, 'D': 4.253, 'E': 12.702, 'F': 2.228,
    'G': 2.015, 'H': 6.094, 'I': 6.966, 'J': 0.153, 'K': 0.772, 'L': 4.025,
    'M': 2.406, 'N': 6.749, 'O': 7.507, 'P': 1.929, 'Q': 0.095, 'R': 5.987,
    'S': 6.327, 'T': 9.056, 'U': 2.758, 'V': 0.978, 'W': 2.360, 'X': 0.150,
    'Y': 1.974, 'Z': 0.074
}

ct = input("Enter Ciphertext: ")

# Store results as a list of lists: [score, shift, decrypted_text]
results = []

for shift in range(26):
    # Decrypt with this shift
    decrypted = ""
    for char in ct:
        if char >= 'A' and char <= 'Z':
            decrypted += chr(((ord(char) - 65 - shift) % 26) + 65)
        elif char >= 'a' and char <= 'z':
            decrypted += chr(((ord(char) - 97 - shift) % 26) + 97)
        else:
            decrypted += char
            
    # Calculate score based on frequencies
    score = 0
    for char in decrypted.upper():
        if char >= 'A' and char <= 'Z':
            # Add frequency if letter exists in dictionary
            if char in english_freq:
                score += english_freq[char]
                
    results.append([score, shift, decrypted])

# Simple sort (Bubble sort) to rank by score descending
for i in range(len(results)):
    for j in range(len(results) - 1):
        if results[j][0] < results[j+1][0]:
            # Swap
            temp = results[j]
            results[j] = results[j+1]
            results[j+1] = temp

print("\n--- Frequency Attack Top 10 Results ---")
for i in range(10):
    score = results[i][0]
    shift = results[i][1]
    pt = results[i][2]
    # Simple formatting
    if shift < 10:
        shift_str = "0" + str(shift)
    else:
        shift_str = str(shift)
        
    print("Rank " + str(i+1) + ": Shift " + shift_str + " | Plaintext: " + pt)
