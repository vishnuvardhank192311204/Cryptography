# Experiment 15: Frequency Attack

## Aim
To perform a frequency attack on a Caesar ciphertext and rank the top 10 most likely plaintexts.

## Algorithm
1. Define standard English letter frequencies.
2. For every possible shift (0-25), decrypt the ciphertext.
3. Score each decrypted text by summing the standard frequencies of the letters it contains.
4. Sort the results in descending order of score.
5. Display the top 10 most likely plaintexts.

## Program
The program is implemented in `frequency_attack.py`.

## Sample Input
Ciphertext: KHOOR ZRUOG

## Sample Output
Ranked plaintexts with HELLO WORLD at the top.

## Result
The Frequency attack was successfully implemented and displayed the top 10 plaintexts.
