# Experiment 13: Hill Known Plaintext Attack

## Aim
To recover the key matrix of a Hill cipher given known plaintext and corresponding ciphertext.

## Algorithm
1. Take at least 4 letters of known plaintext and its corresponding ciphertext.
2. Form matrices P and C from the pairs of letters.
3. Calculate the modular inverse of the plaintext matrix (P^-1 mod 26).
4. Recover the key matrix K by multiplying C by P^-1 mod 26.

## Program
The program is implemented in `hill_known_plaintext.py`.

## Sample Input
Plaintext: HELP
Ciphertext: HIAT

## Sample Output
Recovered Matrix

## Result
The Hill Known Plaintext attack was successfully implemented.
