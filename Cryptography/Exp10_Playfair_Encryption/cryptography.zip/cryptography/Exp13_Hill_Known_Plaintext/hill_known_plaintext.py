# Hill Known Plaintext Attack (No NumPy)
pt = input("Enter 4 letters of plaintext: ")
ct = input("Enter corresponding 4 letters of ciphertext: ")

print("\n--- Hill Known Plaintext Attack ---")

pt = pt.upper()
ct = ct.upper()

if len(pt) >= 4 and len(ct) >= 4:
    # P = [[pt[0], pt[2]], 
    #      [pt[1], pt[3]]]
    P = [[ord(pt[0]) - 65, ord(pt[2]) - 65],
         [ord(pt[1]) - 65, ord(pt[3]) - 65]]
         
    # C = [[ct[0], ct[2]], 
    #      [ct[1], ct[3]]]
    C = [[ord(ct[0]) - 65, ord(ct[2]) - 65],
         [ord(ct[1]) - 65, ord(ct[3]) - 65]]
         
    # Find determinant of P
    det = (P[0][0] * P[1][1] - P[0][1] * P[1][0]) % 26
    
    # Find modular inverse of determinant
    det_inv = 0
    for i in range(1, 26):
        if (det * i) % 26 == 1:
            det_inv = i
            break
            
    if det_inv == 0:
        print("Matrix P is not invertible modulo 26")
    else:
        # Find inverse of P
        P_inv = [[0, 0], [0, 0]]
        P_inv[0][0] = (P[1][1] * det_inv) % 26
        P_inv[0][1] = (-P[0][1] * det_inv) % 26
        P_inv[1][0] = (-P[1][0] * det_inv) % 26
        P_inv[1][1] = (P[0][0] * det_inv) % 26
        
        # Calculate K = C * P_inv
        K = [[0, 0], [0, 0]]
        K[0][0] = (C[0][0] * P_inv[0][0] + C[0][1] * P_inv[1][0]) % 26
        K[0][1] = (C[0][0] * P_inv[0][1] + C[0][1] * P_inv[1][1]) % 26
        K[1][0] = (C[1][0] * P_inv[0][0] + C[1][1] * P_inv[1][0]) % 26
        K[1][1] = (C[1][0] * P_inv[0][1] + C[1][1] * P_inv[1][1]) % 26
        
        print("Recovered Key Matrix:")
        print("[[" + str(K[0][0]) + " " + str(K[0][1]) + "]")
        print(" [" + str(K[1][0]) + " " + str(K[1][1]) + "]]")
else:
    print("Need at least 4 letters.")
