# Affine Cipher Break (Brute Force)
ciphertext = input("Enter the ciphertext to break: ")

print("\n--- Brute Forcing Affine Cipher ---")
print("Ciphertext:", ciphertext, "\n")

possible_as = [1, 3, 5, 7, 9, 11, 15, 17, 19, 21, 23, 25]

for a in possible_as:
    # Find inverse of 'a'
    a_inv = 0
    for i in range(1, 26):
        if (a * i) % 26 == 1:
            a_inv = i
            break
            
    for b in range(26):
        decrypted = ""
        for char in ciphertext:
            if char >= 'A' and char <= 'Z':
                y = ord(char) - 65
                decrypted += chr(((a_inv * (y - b)) % 26) + 65)
            elif char >= 'a' and char <= 'z':
                y = ord(char) - 97
                decrypted += chr(((a_inv * (y - b)) % 26) + 97)
            else:
                decrypted += char
                
        # Check if "THE" is in decrypted text to filter results
        if "THE" in decrypted.upper():
            print("Key (a=" + str(a) + ", b=" + str(b) + "): " + decrypted)

print("Brute force complete. Check results for readable text.")
