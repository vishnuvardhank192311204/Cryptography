# Experiment 6: Affine Cipher Break

## Aim
To break the Affine Cipher using a brute-force approach.

## Algorithm
1. The Affine cipher key space is small: 12 valid values for `a` and 26 for `b`.
2. Iterate through all 12 * 26 = 312 possible keys.
3. Decrypt the ciphertext with each key pair.
4. Filter or display results that contain common English words (e.g., "THE") to identify the correct plaintext.

## Program
The program is implemented in `affine_cipher_break.py`.

## Sample Input
Ciphertext: IHHWVC SWFRCP (Encrypted "AFFINE CIPHER" with a=5, b=8)

## Sample Output
Key (a=5, b=8): AFFINE CIPHER

## Result
The Affine cipher was successfully broken.
