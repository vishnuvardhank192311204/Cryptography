import string
from collections import Counter

# Simplified English bigrams
COMMON_BIGRAMS = ["TH", "HE", "IN", "ER", "AN", "RE", "ON", "AT", "EN", "ND", "TI", "ES", "OR", "TE", "OF", "ED", "IS", "IT", "AL", "AR", "ST", "TO", "NT", "NG", "SE", "HA", "AS", "OU", "IO", "LE", "VE", "CO", "ME", "DE", "HI", "RI", "RO", "IC", "NE", "EA", "RA", "CE"]

def count_bigrams(text):
    bigrams = Counter()
    for i in range(len(text) - 1):
        if text[i] in string.ascii_uppercase and text[i+1] in string.ascii_uppercase:
            bigrams[text[i:i+2]] += 1
    return bigrams

def score_text(text):
    score = 0
    bg_counts = count_bigrams(text)
    for bg in COMMON_BIGRAMS[:15]:
        score += bg_counts.get(bg, 0) * 2
    return score

def mono_attack():
    print("--- Monoalphabetic Frequency Attack (Digrams) ---")
    ct = input("Enter ciphertext: ").upper()
    n_str = input("How many candidates to display (default 5): ")
    n = int(n_str) if n_str.isdigit() else 5
    
    # For demonstration, we simply generate Caesar shifts as candidates, but score them
    # using digram analysis to show an improved scoring metric.
    # A full substitution solver requires hill climbing (see Exp 40).
    
    candidates = []
    for shift in range(26):
        pt = ""
        for c in ct:
            if c in string.ascii_uppercase:
                pt += chr(((ord(c) - 65 - shift) % 26) + 65)
            else:
                pt += c
        candidates.append((score_text(pt), pt, f"Shift {shift}"))
        
    candidates.sort(reverse=True, key=lambda x: x[0])
    
    print(f"\nDisplaying top candidates based on Digram scoring:\n")
    for i in range(min(n, len(candidates))):
        print(f"Rank {i+1} (Score: {candidates[i][0]}) - {candidates[i][2]}")
        print(f"{candidates[i][1]}\n")

if __name__ == "__main__":
    mono_attack()
