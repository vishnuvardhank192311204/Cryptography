# Playfair PT-109 Decryption
ciphertext = input("Enter the PT-109 Ciphertext: ")
keyword = input("Enter the Key: ")

# 1. Create Matrix
matrix = []
alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"
keyword = keyword.upper()

for char in keyword:
    if char == 'J': char = 'I'
    if char not in matrix and char in alphabet:
        matrix.append(char)

for char in alphabet:
    if char not in matrix:
        matrix.append(char)

# 2. Format Ciphertext (remove spaces, ensure even length)
clean_text = ""
for char in ciphertext.upper():
    if char >= 'A' and char <= 'Z':
        clean_text += char

if len(clean_text) % 2 != 0:
    clean_text += 'X'

# 3. Decrypt
decrypted = ""
for i in range(0, len(clean_text), 2):
    a = clean_text[i]
    b = clean_text[i+1]
    
    r1, c1, r2, c2 = 0, 0, 0, 0
    for j in range(25):
        if matrix[j] == a:
            r1 = j // 5
            c1 = j % 5
        if matrix[j] == b:
            r2 = j // 5
            c2 = j % 5
            
    if r1 == r2:
        decrypted += matrix[r1 * 5 + ((c1 - 1) % 5)]
        decrypted += matrix[r2 * 5 + ((c2 - 1) % 5)]
    elif c1 == c2:
        decrypted += matrix[((r1 - 1) % 5) * 5 + c1]
        decrypted += matrix[((r2 - 1) % 5) * 5 + c2]
    else:
        decrypted += matrix[r1 * 5 + c2]
        decrypted += matrix[r2 * 5 + c1]

print("\n--- PT-109 Decryption ---")
print("Decrypted text:", decrypted)
