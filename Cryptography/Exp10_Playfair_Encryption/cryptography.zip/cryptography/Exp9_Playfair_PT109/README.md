# Experiment 9: Playfair PT-109

## Aim
To decrypt the historical PT-109 ciphertext using the Playfair cipher.

## Algorithm
1. Generate a 5x5 key matrix using the given keyword (e.g., "ROYAL NEW ZEALAND NAVY").
2. Read the ciphertext and divide it into pairs.
3. Decrypt using standard Playfair rules:
   - Same row: Shift left.
   - Same column: Shift up.
   - Rectangle: Swap corners on the same row.

## Program
The program is implemented in `playfair_pt109.py`.

## Sample Input
Ciphertext: KXJEY UREBE ZWEHE WRYTU HEYFS KREHE GOYFI WTTTU SYXAH HEYTO DPTYY TIBQA REKWA RPECH YODKJ YXHRO Z
Key: ROYAL NEW ZEALAND NAVY

## Sample Output
Decrypted text: AMXCOASTXWATCHERXREPORTXENEMYXFORCE...

## Result
The PT-109 Playfair decryption was successfully implemented and executed.
