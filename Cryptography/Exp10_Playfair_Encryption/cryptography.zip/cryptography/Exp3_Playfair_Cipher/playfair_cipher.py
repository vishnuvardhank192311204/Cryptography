# Playfair Cipher
keyword = input("Enter the keyword: ")
plaintext = input("Enter the plaintext: ")

# 1. Create Matrix
matrix = []
alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"
keyword = keyword.upper()

# Add keyword letters
for char in keyword:
    if char == 'J': char = 'I'
    if char not in matrix and char in alphabet:
        matrix.append(char)

# Add remaining alphabet
for char in alphabet:
    if char not in matrix:
        matrix.append(char)

# 2. Format Plaintext
formatted_text = ""
for char in plaintext.upper():
    if char == 'J': char = 'I'
    if char >= 'A' and char <= 'Z':
        formatted_text += char

pairs = []
i = 0
while i < len(formatted_text):
    a = formatted_text[i]
    if i + 1 < len(formatted_text):
        b = formatted_text[i+1]
        if a == b:
            pairs.append(a + 'X')
            i += 1
        else:
            pairs.append(a + b)
            i += 2
    else:
        pairs.append(a + 'X')
        i += 1

# 3. Encrypt and Decrypt
def process_playfair(pairs_list, shift):
    result = ""
    for pair in pairs_list:
        a = pair[0]
        b = pair[1]
        
        # Find rows and columns
        r1, c1, r2, c2 = 0, 0, 0, 0
        for i in range(25):
            if matrix[i] == a:
                r1 = i // 5
                c1 = i % 5
            if matrix[i] == b:
                r2 = i // 5
                c2 = i % 5
                
        if r1 == r2:
            result += matrix[r1 * 5 + ((c1 + shift) % 5)]
            result += matrix[r2 * 5 + ((c2 + shift) % 5)]
        elif c1 == c2:
            result += matrix[((r1 + shift) % 5) * 5 + c1]
            result += matrix[((r2 + shift) % 5) * 5 + c2]
        else:
            result += matrix[r1 * 5 + c2]
            result += matrix[r2 * 5 + c1]
    return result

print("\n--- Encryption ---")
ciphertext = process_playfair(pairs, 1)
print("Plaintext:", plaintext)
print("Ciphertext:", ciphertext)

print("\n--- Decryption ---")
cipher_pairs = []
for i in range(0, len(ciphertext), 2):
    cipher_pairs.append(ciphertext[i:i+2])
    
decrypted = process_playfair(cipher_pairs, -1)
print("Decrypted text:", decrypted)
