# Experiment 3: Playfair Cipher

## Aim
To implement the Playfair Cipher.

## Algorithm
1. Generate a 5x5 key matrix using the given keyword (treating I and J as the same letter).
2. Format the plaintext into digraphs (pairs of letters), appending 'X' if necessary or separating double letters with 'X'.
3. Encrypt each digraph based on the Playfair rules:
   - Same row: Shift right.
   - Same column: Shift down.
   - Rectangle: Swap corners on the same row.
4. Decrypt by reversing the shifts.

## Program
The program is implemented in `playfair_cipher.py`.

## Sample Input
Keyword: MONARCHY
Plaintext: INSTRUMENTS

## Sample Output
Ciphertext: GATLMZCLRQTX
Decrypted text: INSTRUMENTSX

## Result
The Playfair cipher was successfully implemented and executed.
