# Experiment 2: Monoalphabetic Cipher

## Aim
To implement the Monoalphabetic Substitution Cipher.

## Algorithm
1. Define a mapping between the standard alphabet and a permuted alphabet.
2. To encrypt, replace each letter in the plaintext with its corresponding letter in the permuted alphabet.
3. To decrypt, reverse the mapping and replace each letter in the ciphertext with its corresponding letter in the standard alphabet.

## Program
The program is implemented in `monoalphabetic_cipher.py`.

## Sample Input
Plaintext: Cryptography

## Sample Output
Ciphertext: VKOFZHUKQJIO
Decrypted text: CRYPTOGRAPHY

## Result
The Monoalphabetic cipher was successfully implemented and executed.
