# Monoalphabetic Cipher
plaintext = input("Enter the plaintext: ")

cipher_alphabet = "QWERTYUIOPASDFGHJKLZXCVBNM"
plain_alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

print("\n--- Encryption ---")
print("Plaintext:", plaintext)
print("Key mapping: A-Z ->", cipher_alphabet)

ciphertext = ""
for char in plaintext:
    char_upper = char.upper()
    found = False
    for i in range(26):
        if char_upper == plain_alphabet[i]:
            ciphertext += cipher_alphabet[i]
            found = True
            break
    if not found:
        ciphertext += char

print("Ciphertext:", ciphertext)

print("\n--- Decryption ---")
decrypted = ""
for char in ciphertext:
    found = False
    for i in range(26):
        if char == cipher_alphabet[i]:
            decrypted += plain_alphabet[i]
            found = True
            break
    if not found:
        decrypted += char

print("Decrypted text:", decrypted)
