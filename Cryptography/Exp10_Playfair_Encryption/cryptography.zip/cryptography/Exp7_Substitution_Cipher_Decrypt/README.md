# Experiment 7: Substitution Cipher Decrypt

## Aim
To decrypt a message encrypted with a Monoalphabetic Substitution Cipher given the cipher alphabet.

## Algorithm
1. Receive the ciphertext and the 26-letter cipher alphabet mapping.
2. Create a reverse mapping from the cipher alphabet back to the standard alphabet.
3. Replace each letter in the ciphertext using the reverse mapping to get the plaintext.

## Program
The program is implemented in `substitution_decrypt.py`.

## Sample Input
Ciphertext: VKOFZHUKQJIO
Cipher Alphabet: QWERTYUIOPASDFGHJKLZXCVBNM

## Sample Output
Decrypted text: CRYPTOGRAPHY

## Result
The Substitution cipher decryption was successfully implemented and executed.
