# Substitution Cipher Decrypt
ciphertext = input("Enter the ciphertext: ")
cipher_alphabet = input("Enter the 26-letter cipher alphabet (A-Z mapped): ")
plain_alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

print("\n--- Decryption ---")
print("Ciphertext:", ciphertext)

decrypted = ""
for char in ciphertext:
    char_upper = char.upper()
    found = False
    for i in range(26):
        if char_upper == cipher_alphabet[i]:
            # Keep original case if possible, but simplicity first: make it uppercase
            decrypted += plain_alphabet[i]
            found = True
            break
    if not found:
        decrypted += char

print("Decrypted text:", decrypted)
