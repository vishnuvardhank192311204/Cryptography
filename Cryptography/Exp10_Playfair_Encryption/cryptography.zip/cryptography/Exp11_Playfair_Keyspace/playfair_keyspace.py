# Playfair Keyspace Calculation

print("\n--- Playfair Keyspace ---")

# Calculate factorial of 25 using a simple loop
factorial = 1
for i in range(1, 26):
    factorial = factorial * i

print("Total possible Playfair matrices: 25! = " + str(factorial))

# To find power of 2, we can just divide by 2 repeatedly
temp = factorial
bits = 0
while temp > 1:
    temp = temp // 2
    bits += 1

print("Approximate keyspace in bits: 2^" + str(bits))
