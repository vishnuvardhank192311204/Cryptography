# Experiment 11: Playfair Keyspace

## Aim
To calculate the total keyspace of the Playfair cipher.

## Algorithm
1. The Playfair matrix consists of 25 distinct letters.
2. The number of ways to arrange 25 letters in a 5x5 grid is 25!.
3. Calculate 25! using factorial function.

## Program
The program is implemented in `playfair_keyspace.py`.

## Sample Input
None (Calculation is mathematical)

## Sample Output
25! = 15511210043330985984000000

## Result
The Playfair keyspace was successfully calculated.
