def sha3_lane_propagation():
    print("--- SHA-3 Lane Propagation Simulation ---")
    
    state_size = 1600
    block_size = 1024 # Rate (r)
    capacity = state_size - block_size # 576 bits
    lane_size = 64
    
    total_lanes = state_size // lane_size # 25
    rate_lanes = block_size // lane_size # 16
    capacity_lanes = capacity // lane_size # 9
    
    print(f"Total Lanes: {total_lanes}")
    print(f"Rate Lanes (r): {rate_lanes}")
    print(f"Capacity Lanes (c): {capacity_lanes}\n")
    
    # State tracking: True if lane has non-zero bit, False if all zeros
    lanes = [False] * total_lanes
    
    # Block 1
    print("Processing Block P0...")
    print("XORing P0 into the rate lanes (first 16 lanes).")
    for i in range(rate_lanes):
        lanes[i] = True
        
    print(f"Zero lanes remaining (Capacity part): {lanes.count(False)}")
    
    print("\nWait, the question says: 'Ignore the permutation. That is, keep track")
    print("of the original zero lanes even after they have changed position in the matrix.'")
    print("If we completely ignore the mixing power of the permutation 'f', the capacity")
    print("lanes are NEVER directly XORed with message bits.")
    
    print("\nAnswer & Conclusion:")
    print("If the permutation 'f' does not mix the bits (i.e., we ignore the permutation),")
    print("then NO message bits will ever enter the capacity lanes.")
    print("It will take an INFINITE number of blocks before all lanes have a nonzero bit,")
    print("because the capacity lanes are completely isolated from the rate lanes.")
    print("\nIn the real SHA-3 algorithm, the Keccak-f permutation strongly mixes ALL 25")
    print("lanes together after every block insertion, ensuring that the nonzero bits from")
    print("the rate quickly diffuse into the capacity lanes.")

if __name__ == "__main__":
    sha3_lane_propagation()
