# Experiment 12: Hill Cipher

## Aim
To implement the Hill cipher using the specific key [9 4; 5 7].

## Algorithm
1. Convert plaintext into a sequence of numbers (A=0, ..., Z=25).
2. Group the numbers into vectors of size 2.
3. Multiply each vector by the key matrix modulo 26 to get the ciphertext.
4. To decrypt, find the modular inverse of the key matrix.
5. Multiply the ciphertext vectors by the inverse matrix modulo 26 to recover the plaintext.

## Program
The program is implemented in `hill_cipher.py`.

## Sample Input
Plaintext: MEET ME AT THE USUAL PLACE
Key: [[9, 4], [5, 7]]

## Sample Output
Ciphertext: ...
Decrypted text: MEETMEATTHEUSUALPLACEX

## Result
The Hill cipher encryption and decryption were successfully implemented and executed.
