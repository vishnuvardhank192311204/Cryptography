# Hill Cipher (No NumPy)

# Define Key Matrix [9 4; 5 7]
K = [[9, 4], 
     [5, 7]]

plaintext = input("Enter the plaintext: ")
print("Using predefined key: [[9, 4], [5, 7]]")
print("\n--- Hill Cipher ---")

# Clean plaintext
clean_text = ""
for char in plaintext.upper():
    if char >= 'A' and char <= 'Z':
        clean_text += char

if len(clean_text) % 2 != 0:
    clean_text += "X"

# Encrypt
ciphertext = ""
for i in range(0, len(clean_text), 2):
    p1 = ord(clean_text[i]) - 65
    p2 = ord(clean_text[i+1]) - 65
    
    # Matrix multiplication
    c1 = (K[0][0] * p1 + K[0][1] * p2) % 26
    c2 = (K[1][0] * p1 + K[1][1] * p2) % 26
    
    ciphertext += chr(c1 + 65) + chr(c2 + 65)

print("Ciphertext:", ciphertext)

# Decrypt
# 1. Find determinant of K: (9*7 - 4*5)
det = (K[0][0] * K[1][1] - K[0][1] * K[1][0]) % 26

# 2. Find modular inverse of determinant
det_inv = 0
for i in range(1, 26):
    if (det * i) % 26 == 1:
        det_inv = i
        break

# 3. Find inverse matrix
K_inv = [[0, 0], [0, 0]]
K_inv[0][0] = (K[1][1] * det_inv) % 26
K_inv[0][1] = (-K[0][1] * det_inv) % 26
K_inv[1][0] = (-K[1][0] * det_inv) % 26
K_inv[1][1] = (K[0][0] * det_inv) % 26

decrypted = ""
for i in range(0, len(ciphertext), 2):
    c1 = ord(ciphertext[i]) - 65
    c2 = ord(ciphertext[i+1]) - 65
    
    p1 = (K_inv[0][0] * c1 + K_inv[0][1] * c2) % 26
    p2 = (K_inv[1][0] * c1 + K_inv[1][1] * c2) % 26
    
    decrypted += chr(p1 + 65) + chr(p2 + 65)

print("Decrypted text:", decrypted)
