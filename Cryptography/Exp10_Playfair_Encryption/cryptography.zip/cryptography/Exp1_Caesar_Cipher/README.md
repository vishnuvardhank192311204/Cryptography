# Experiment 1: Caesar Cipher

## Aim
To implement the Caesar cipher encryption and decryption algorithms.

## Algorithm
1. Read the plaintext and the shift key.
2. For each character in the plaintext:
   - If it's an uppercase letter, shift it by the key modulo 26.
   - If it's a lowercase letter, shift it by the key modulo 26.
   - Otherwise, leave it as is.
3. For decryption, shift the ciphertext in the opposite direction.

## Program
The program is implemented in `caesar_cipher.py`.

## Sample Input
Plaintext: Hello World
Key: 3

## Sample Output
Ciphertext: Khoor Zruog
Decrypted text: Hello World

## Result
The Caesar cipher was successfully implemented and executed.
