# Caesar Cipher
plaintext = input("Enter the plaintext: ")
shift = int(input("Enter the shift key: "))

print("\n--- Encryption ---")
print("Plaintext:", plaintext)

ciphertext = ""
for char in plaintext:
    if char >= 'A' and char <= 'Z':
        new_char = chr(((ord(char) - 65 + shift) % 26) + 65)
        ciphertext += new_char
    elif char >= 'a' and char <= 'z':
        new_char = chr(((ord(char) - 97 + shift) % 26) + 97)
        ciphertext += new_char
    else:
        ciphertext += char

print("Ciphertext:", ciphertext)

print("\n--- Decryption ---")
decrypted = ""
for char in ciphertext:
    if char >= 'A' and char <= 'Z':
        new_char = chr(((ord(char) - 65 - shift) % 26) + 65)
        decrypted += new_char
    elif char >= 'a' and char <= 'z':
        new_char = chr(((ord(char) - 97 - shift) % 26) + 97)
        decrypted += new_char
    else:
        decrypted += char

print("Decrypted text:", decrypted)
