# Experiment 5: Affine Cipher

## Aim
To implement the Affine Cipher encryption and decryption.

## Algorithm
1. The cipher uses two keys `a` and `b`, where `a` must be coprime to 26.
2. Encryption function: `E(x) = (a * x + b) mod 26`.
3. Decryption function: `D(y) = a^-1 * (y - b) mod 26`, where `a^-1` is the modular multiplicative inverse of `a` modulo 26.

## Program
The program is implemented in `affine_cipher.py`.

## Sample Input
Plaintext: AFFINE CIPHER
a: 5
b: 8

## Sample Output
Ciphertext: IHHWVC SWFRCP
Decrypted text: AFFINE CIPHER

## Result
The Affine cipher was successfully implemented and executed.
