# Affine Cipher
plaintext = input("Enter the plaintext: ")
a = int(input("Enter key 'a' (must be coprime with 26): "))
b = int(input("Enter key 'b': "))

print("\n--- Encryption ---")
print("Plaintext:", plaintext)

ciphertext = ""
for char in plaintext:
    if char >= 'A' and char <= 'Z':
        x = ord(char) - 65
        new_char = chr(((a * x + b) % 26) + 65)
        ciphertext += new_char
    elif char >= 'a' and char <= 'z':
        x = ord(char) - 97
        new_char = chr(((a * x + b) % 26) + 97)
        ciphertext += new_char
    else:
        ciphertext += char

print("Ciphertext:", ciphertext)

print("\n--- Decryption ---")
# Find modular inverse using simple loop
a_inv = 0
for i in range(1, 26):
    if (a * i) % 26 == 1:
        a_inv = i
        break

if a_inv == 0:
    print("Invalid key 'a' (no modular inverse).")
else:
    decrypted = ""
    for char in ciphertext:
        if char >= 'A' and char <= 'Z':
            y = ord(char) - 65
            new_char = chr(((a_inv * (y - b)) % 26) + 65)
            decrypted += new_char
        elif char >= 'a' and char <= 'z':
            y = ord(char) - 97
            new_char = chr(((a_inv * (y - b)) % 26) + 97)
            decrypted += new_char
        else:
            decrypted += char
    print("Decrypted text:", decrypted)
