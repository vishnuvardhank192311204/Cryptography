import string
from collections import Counter

ENGLISH_FREQ = {
    'E': 12.7, 'T': 9.1, 'A': 8.2, 'O': 7.5, 'I': 7.0, 'N': 6.7, 'S': 6.3, 'H': 6.1, 'R': 6.0,
    'D': 4.3, 'L': 4.0, 'C': 2.8, 'U': 2.8, 'M': 2.4, 'W': 2.4, 'F': 2.2, 'G': 2.0, 'Y': 2.0,
    'P': 1.9, 'B': 1.5, 'V': 0.9, 'K': 0.8, 'J': 0.15, 'X': 0.15, 'Q': 0.10, 'Z': 0.07
}

def score_text(text):
    score = 0
    counts = Counter([c for c in text if c in string.ascii_uppercase])
    total = sum(counts.values())
    if total == 0: return 0
    for char, count in counts.items():
        freq = (count / total) * 100
        if char in ENGLISH_FREQ:
            score -= abs(freq - ENGLISH_FREQ[char])
        else:
            score -= freq
    return score

def additive_attack():
    print("--- Additive (Caesar) Cipher Auto Attack ---")
    ct = input("Enter ciphertext: ").upper()
    n_str = input("How many top candidates to show (default 5): ")
    n = int(n_str) if n_str.isdigit() else 5
    
    candidates = []
    
    # Try all 26 shifts
    for shift in range(26):
        pt = ""
        for c in ct:
            if c in string.ascii_uppercase:
                pt += chr(((ord(c) - 65 - shift) % 26) + 65)
            else:
                pt += c
        
        score = score_text(pt)
        candidates.append((score, shift, pt))
        
    # Sort by score descending (higher is better)
    candidates.sort(reverse=True, key=lambda x: x[0])
    
    print(f"\nTop {n} Candidates:")
    for i in range(min(n, len(candidates))):
        score, shift, text = candidates[i]
        print(f"Rank {i+1} | Shift: {shift:2d} | Score: {score:8.2f} | Text: {text}")

if __name__ == "__main__":
    additive_attack()
