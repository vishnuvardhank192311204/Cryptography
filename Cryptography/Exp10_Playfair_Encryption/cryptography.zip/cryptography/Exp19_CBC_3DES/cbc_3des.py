from Crypto.Cipher import DES3
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import binascii

def des3_cbc_demo():
    print("--- CBC with 3DES Demonstration ---")
    
    # User Input
    plaintext = input("Enter plaintext to encrypt: ").encode('utf-8')
    
    # Generate random 24-byte key (3DES requires 16 or 24 bytes)
    # and 8-byte IV
    key = get_random_bytes(24)
    iv = get_random_bytes(8)
    
    print(f"\nKey (Hex): {binascii.hexlify(key).decode()}")
    print(f"IV (Hex): {binascii.hexlify(iv).decode()}")
    
    # Pad plaintext to match 8-byte block size
    padded_pt = pad(plaintext, DES3.block_size)
    
    # Encrypt
    cipher = DES3.new(key, DES3.MODE_CBC, iv)
    ciphertext = cipher.encrypt(padded_pt)
    
    print(f"\nPlaintext blocks (Hex): {binascii.hexlify(padded_pt).decode()}")
    print(f"Ciphertext (Hex): {binascii.hexlify(ciphertext).decode()}")
    
    print("\nWhy 3DES is stronger than DES:")
    print("1. Security: DES uses a 56-bit key, which is vulnerable to brute-force attacks.")
    print("   3DES applies the DES algorithm three times, expanding the effective key size")
    print("   to 112 or 168 bits, mitigating brute-force risks.")
    print("2. Performance: 3DES is about 3 times slower than DES because it runs the DES")
    print("   algorithm three times per block. However, the security gain outweighs the")
    print("   performance penalty, making it a better choice where modern algorithms (AES)")
    print("   are unavailable.")

if __name__ == "__main__":
    des3_cbc_demo()
