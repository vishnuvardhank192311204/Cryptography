# Keyword Monoalphabetic Cipher
plaintext = input("Enter the plaintext: ")
keyword = input("Enter the keyword: ")

plain_alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
keyword = keyword.upper()

# Generate cipher alphabet
cipher_alphabet = ""
# Add keyword letters (no duplicates)
for char in keyword:
    if char != " " and char not in cipher_alphabet:
        cipher_alphabet += char

# Add remaining letters
for char in plain_alphabet:
    if char not in cipher_alphabet:
        cipher_alphabet += char

print("\n--- Encryption ---")
print("Generated Cipher Alphabet:", cipher_alphabet)

ciphertext = ""
for char in plaintext:
    char_upper = char.upper()
    found = False
    for i in range(26):
        if char_upper == plain_alphabet[i]:
            ciphertext += cipher_alphabet[i]
            found = True
            break
    if not found:
        ciphertext += char

print("Ciphertext:", ciphertext)
