# Experiment 8: Keyword Monoalphabetic Cipher

## Aim
To implement a Monoalphabetic Cipher where the cipher alphabet is generated using a keyword.

## Algorithm
1. Take a keyword, remove duplicate letters and spaces.
2. Form the cipher alphabet by starting with the processed keyword, followed by the remaining letters of the standard alphabet in order.
3. Use this generated alphabet to perform standard substitution encryption.

## Program
The program is implemented in `keyword_monoalphabetic.py`.

## Sample Input
Plaintext: SECRET MESSAGE
Keyword: KRYPTOS

## Sample Output
Ciphertext: OAZQAR JCOOPCA

## Result
The Keyword Monoalphabetic cipher was successfully implemented.
