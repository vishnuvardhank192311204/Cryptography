# DES Decryption Key Generation Simulation
# Demonstrating the reverse key schedule for decryption

def generate_shifts():
    # Standard DES left shifts per round for encryption
    # Rounds 1, 2, 9, 16 have shift=1, others have shift=2
    shifts = [1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1]
    return shifts

def simulate_keys():
    print("--- DES Key Schedule Simulation ---")
    shifts = generate_shifts()
    
    # Simulate generating K1 to K16
    keys = []
    print("\nEncryption Key Order:")
    for round_num in range(1, 17):
        keys.append(f"K{round_num}")
        print(f"Round {round_num}: Generated K{round_num} (Shift: {shifts[round_num-1]})")
        
    print("\nDecryption Key Order (Reverse):")
    # For decryption, the keys are used in reverse order K16 -> K1
    for i, key in enumerate(reversed(keys)):
        print(f"Decryption Round {i+1}: Uses {key}")
        
    print("\nRelationship Explanation:")
    print("During encryption, the data block passes through 16 Feistel rounds using K1 to K16.")
    print("Because the Feistel network is symmetric, decryption is exactly the same operation")
    print("as encryption, but the subkeys are applied in the reverse order (K16 down to K1).")
    print("The key generation scheme achieves this by either generating all keys upfront")
    print("or by reversing the shift schedule (using right shifts instead of left shifts).")

if __name__ == "__main__":
    simulate_keys()
