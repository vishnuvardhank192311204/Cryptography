# Playfair Encryption
plaintext = input("Enter the plaintext: ")
print("Enter the 5x5 matrix (25 letters, e.g. from keyword LARGEST):")
matrix_str = input()

# 1. Create Matrix
matrix = []
for char in matrix_str.upper():
    if char >= 'A' and char <= 'Z':
        matrix.append(char)

# 2. Format Plaintext
clean_text = ""
for char in plaintext.upper():
    if char == 'J': char = 'I'
    if char >= 'A' and char <= 'Z':
        clean_text += char

pairs = []
i = 0
while i < len(clean_text):
    a = clean_text[i]
    if i + 1 < len(clean_text):
        b = clean_text[i+1]
        if a == b:
            pairs.append(a + 'X')
            i += 1
        else:
            pairs.append(a + b)
            i += 2
    else:
        pairs.append(a + 'X')
        i += 1

# 3. Encrypt
ciphertext = ""
for pair in pairs:
    a = pair[0]
    b = pair[1]
    
    r1, c1, r2, c2 = 0, 0, 0, 0
    for j in range(25):
        if matrix[j] == a:
            r1 = j // 5
            c1 = j % 5
        if matrix[j] == b:
            r2 = j // 5
            c2 = j % 5
            
    if r1 == r2:
        ciphertext += matrix[r1 * 5 + ((c1 + 1) % 5)]
        ciphertext += matrix[r2 * 5 + ((c2 + 1) % 5)]
    elif c1 == c2:
        ciphertext += matrix[((r1 + 1) % 5) * 5 + c1]
        ciphertext += matrix[((r2 + 1) % 5) * 5 + c2]
    else:
        ciphertext += matrix[r1 * 5 + c2]
        ciphertext += matrix[r2 * 5 + c1]

print("\n--- Playfair Encryption ---")
print("Plaintext:", plaintext)
print("Ciphertext:", ciphertext)
