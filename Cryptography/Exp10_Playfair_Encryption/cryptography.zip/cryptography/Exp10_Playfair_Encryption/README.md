# Experiment 10: Playfair Encryption

## Aim
To encrypt a specific message using a provided Playfair matrix.

## Algorithm
1. Read the 5x5 Playfair matrix exactly as provided.
2. Read the plaintext message.
3. Process the plaintext into digraphs according to Playfair rules (inserting 'X' for duplicates or odd-length strings).
4. Encrypt the digraphs using the standard Playfair rules using the loaded matrix.

## Program
The program is implemented in `playfair_encrypt.py`.

## Sample Input
Plaintext: Must see you over Cadogan West. Coming at once.
Matrix: L A R G E S T B C D F H I K M N O P Q U V W X Y Z

## Sample Output
Ciphertext: (Generated Ciphertext)

## Result
The Playfair encryption was successfully implemented and executed.
