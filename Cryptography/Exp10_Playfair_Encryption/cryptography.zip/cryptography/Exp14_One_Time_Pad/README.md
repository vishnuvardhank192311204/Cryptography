# Experiment 14: One Time Pad

## Aim
To implement the One-Time Pad encryption and decryption, and complete part (b).

## Algorithm
1. Convert plaintext and keystream into numeric values.
2. For encryption, add the values of the plaintext and the pad, modulo 26.
3. For decryption, subtract the pad value from the ciphertext, modulo 26.
4. Part (b) explores further properties as requested in the assignment.

## Program
The program is implemented in `one_time_pad.py`.

## Sample Input
Plaintext: HELLO
Pad: XMCKL

## Sample Output
Ciphertext: ...

## Result
The OTP cipher was successfully implemented.
