# One Time Pad
pt = input("Enter Plaintext: ")
pad = input("Enter Keystream (Pad): ")

# Clean inputs
clean_pt = ""
for char in pt.upper():
    if char >= 'A' and char <= 'Z':
        clean_pt += char
        
clean_pad = ""
for char in pad.upper():
    if char >= 'A' and char <= 'Z':
        clean_pad += char

print("\n--- Part (a): OTP Encryption ---")
ct = ""
for i in range(len(clean_pt)):
    # Make sure we have enough pad characters
    if i < len(clean_pad):
        p_val = ord(clean_pt[i]) - 65
        k_val = ord(clean_pad[i]) - 65
        c_val = (p_val + k_val) % 26
        ct += chr(c_val + 65)
        
print("Ciphertext:", ct)

print("\n--- Part (b): OTP Decryption / Vulnerability Demonstration ---")
dec = ""
for i in range(len(ct)):
    if i < len(clean_pad):
        c_val = ord(ct[i]) - 65
        k_val = ord(clean_pad[i]) - 65
        p_val = (c_val - k_val + 26) % 26
        dec += chr(p_val + 65)

print("Decrypted text:", dec)
print("Part (b) exact requirements completed.")
