from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import binascii

def flip_bit(data, byte_index, bit_index):
    mutable = bytearray(data)
    mutable[byte_index] ^= (1 << bit_index)
    return bytes(mutable)

def error_propagation():
    print("--- ECB / CBC Error Propagation ---")
    
    key = b'16byte_aeskey123'
    iv = b'16byte_init_vect'
    
    # 3 blocks of plaintext
    pt = b'Block1_16bytes!!Block2_16bytes!!Block3_16bytes!!'
    
    print(f"Original Plaintext: {pt}")
    
    # ECB Encrypt
    ecb_cipher = AES.new(key, AES.MODE_ECB)
    ecb_ct = ecb_cipher.encrypt(pt)
    
    # CBC Encrypt
    cbc_cipher = AES.new(key, AES.MODE_CBC, iv)
    cbc_ct = cbc_cipher.encrypt(pt)
    
    # Introduce error in the 1st ciphertext block (C1)
    print("\n[!] Introducing 1 bit error in Ciphertext Block 1 (C1)...")
    ecb_ct_err = flip_bit(ecb_ct, 2, 3)
    cbc_ct_err = flip_bit(cbc_ct, 2, 3)
    
    # ECB Decrypt
    ecb_dec = AES.new(key, AES.MODE_ECB).decrypt(ecb_ct_err)
    # CBC Decrypt
    cbc_dec = AES.new(key, AES.MODE_CBC, iv).decrypt(cbc_ct_err)
    
    print("\n--- Results after C1 error ---")
    print("ECB Decrypted:", ecb_dec)
    print("CBC Decrypted:", cbc_dec)
    
    print("\nAnswers:")
    print("a. If C1 contains an error in CBC, are blocks beyond P2 affected?")
    print("   No. In CBC, an error in C1 completely scrambles P1, and flips the corresponding")
    print("   single bit in P2 (since C1 is XORed with decrypted C2). P3 and beyond are unaffected.")
    print("   You can see above that Block 3 decrypted perfectly in CBC.")
    print("\nb. If there is a bit error in the original P1 before CBC encryption, how far does the error propagate?")
    print("   During encryption, an error in P1 changes C1 entirely. Since C1 is XORed into P2, C2")
    print("   changes entirely, and so on. The error propagates through ALL subsequent ciphertext blocks.")
    print("   However, at the receiver side, decrypting this completely different ciphertext stream")
    print("   will ironically yield exactly the original error. The receiver just sees the bit error in P1,")
    print("   and P2 onwards decrypt perfectly because the new C(i-1) matches the new C(i) decryption.")

if __name__ == "__main__":
    error_propagation()
