def extended_gcd(a, b):
    if a == 0: return b, 0, 1
    gcd_val, x1, y1 = extended_gcd(b % a, a)
    x = y1 - (b // a) * x1
    y = x1
    return gcd_val, x, y

def mod_inverse(e, phi):
    gcd_val, x, y = extended_gcd(e, phi)
    return x % phi if gcd_val == 1 else None

def rsa_key_leak_demo():
    print("--- RSA Private Key Leak Demonstration ---")
    p, q = 61, 53
    n = p * q
    phi = (p - 1) * (q - 1)
    
    e1 = 17
    d1 = mod_inverse(e1, phi)
    
    print("1. Original RSA Parameters:")
    print(f"   Modulus n = {n}")
    print(f"   Public Exponent e1 = {e1}")
    print(f"   Private Key d1 = {d1}")
    
    print("\n2. OH NO! Bob's private key 'd1' is leaked to an attacker.")
    print("   Bob decides to keep 'n' but generate a new (e2, d2) pair.")
    
    e2 = 13
    d2 = mod_inverse(e2, phi)
    
    print(f"\n3. New RSA Parameters:")
    print(f"   Modulus n = {n} (SAME)")
    print(f"   New Public Exponent e2 = {e2}")
    print(f"   New Private Key d2 = {d2}")
    
    print("\n4. Security Implications:")
    print("   Is this safe? NO.")
    print("   If an attacker knows (e1, d1), they know that e1*d1 - 1 is a multiple of φ(n).")
    print("   There are efficient randomized algorithms that can use a multiple of φ(n) to")
    print("   factor 'n' into p and q very quickly.")
    print("   Once the attacker factors 'n', they can compute the new φ(n) and immediately")
    print("   derive Bob's new private key d2 from his new public key e2.")
    print("   Therefore, if a private key leaks, the modulus must be completely discarded.")

if __name__ == "__main__":
    rsa_key_leak_demo()
